import Foundation
import AppKit

struct Dalle2API {
    let apiKey: String
    
    init(apiKey: String) {
        self.apiKey = apiKey
    }

    func generateImage(prompt: String, completion: @escaping (Result<NSImage, Error>) -> Void) {
        let url = URL(string: "https://api.openai.com/v1/images/generations")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "model": "image-alpha-001",
            "prompt": prompt,
            "num_images": 1,
            "size": "512x512",
            "response_format": "url"
        ]
        let requestBody = try! JSONSerialization.data(withJSONObject: body)
        request.httpBody = requestBody
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard error == nil else {
                DispatchQueue.main.async {
                    completion(.failure(error!))
                }
                return
            }
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(.failure(Dalle2APIError.emptyResponse))
                }
                return
            }
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                if let httpResponse = response as? HTTPURLResponse {
                    print("HTTP Status Code: \(httpResponse.statusCode)")
                    print("HTTP Headers: \(httpResponse.allHeaderFields)")
                }
                DispatchQueue.main.async {
                    completion(.failure(Dalle2APIError.invalidResponse))
                }
                return
            }
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                print("JSON Response: \(json ?? [:])")
                if let dataArray = json?["data"] as? [[String: String]], let urlString = dataArray.first?["url"], let url = URL(string: urlString) {
                    URLSession.shared.dataTask(with: url) { data, response, error in
                        guard error == nil else {
                            DispatchQueue.main.async {
                                completion(.failure(error!))
                            }
                            return
                        }
                        guard let data = data else {
                            DispatchQueue.main.async {
                                completion(.failure(Dalle2APIError.emptyResponse))
                            }
                            return
                        }
                        guard let image = NSImage(data: data) else {
                            DispatchQueue.main.async {
                                completion(.failure(Dalle2APIError.invalidImage))
                            }
                            return
                        }
                        DispatchQueue.main.async {
                            completion(.success(image))
                        }
                    }.resume()
                } else {
                    print("Unexpected JSON structure: \(json ?? [:])")
                    DispatchQueue.main.async {
                        completion(.failure(Dalle2APIError.invalidResponse))
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }.resume()
    }

    enum Dalle2APIError: Error {
        case invalidResponse
        case emptyResponse
        case invalidImage
    }
}
