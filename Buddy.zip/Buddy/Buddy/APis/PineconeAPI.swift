import Foundation

struct Query: Encodable {
    let size: Int
    let query: [Double]
    let filters: [String]
    let include_metadata: String

    init(size: Int, query: [Double], filters: [String], include_metadata: Bool) {
        self.size = size
        self.query = query
        self.filters = filters
        self.include_metadata = include_metadata ? "true" : "false"
    }

    private enum CodingKeys: String, CodingKey {
        case size
        case query
        case filters
        case include_metadata
    }
}

class PineconeAPI {
    private let apiKey: String
    private let baseURL = "https://controller.us-east1-gcp.pinecone.io"

    init(apiKey: String) {
        self.apiKey = apiKey
    }

    func queryVectors(queryVector: [Float], size: Int, completion: @escaping (Result<[String], Error>) -> Void) {
        let url = URL(string: "\(baseURL)/query")!

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "content-type")
        request.setValue(apiKey, forHTTPHeaderField: "Api-Key")

        let query = Query(
            size: size,
            query: queryVector.map { Double($0) },
            filters: [],
            include_metadata: false
        )

        do {
            request.httpBody = try JSONEncoder().encode(query)
        } catch {
            completion(.failure(APIError.encodingError(error: error)))
            return
        }

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(APIError.noData))
                return
            }

            do {
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                if let results = (json as? [String: Any])?["results"] as? [String] {
                    completion(.success(results))
                } else {
                    completion(.failure(APIError.parsingError(error: NSError())))
                }
            } catch {
                completion(.failure(APIError.parsingError(error: error)))
            }
        }
        task.resume()
    }

    enum APIError: Error {
        case noData
        case encodingError(error: Error)
        case parsingError(error: Error)
    }
}

