import Foundation

class TerminalBotViewModel: ObservableObject {
    @Published var terminalBot = TerminalBot()
    @Published var messages: [Message] = []
    
    func processCommand(_ command: String) {
        DispatchQueue.global(qos: .userInitiated).async {
            let response = self.terminalBot.execute(command: command)
            DispatchQueue.main.async {
                self.addMessage(content: response, type: .response)
            }
        }
    }
    
    func addMessage(content: String, type: MessageRole) {
        let message = Message(content: content, role: type)
        messages.append(message)
    }
    
    struct Message: Identifiable {
        let id = UUID()
        let content: String
        let role: MessageRole
    }
    
    enum MessageRole {
        case user
        case response
    }
}
