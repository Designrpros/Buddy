import Foundation

func saveAPIKey(_ apiKey: String, for keyName: String) {
    let data = apiKey.data(using: .utf8)!
    
    let query: [String: AnyObject] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrAccount as String: keyName as AnyObject,
        kSecValueData as String: data as AnyObject
    ]
    
    SecItemDelete(query as CFDictionary)
    let status = SecItemAdd(query as CFDictionary, nil)
    if status != errSecSuccess {
        print("Error saving API key: \(status)")
    }
}

func getAPIKey(for keyName: String) -> String? {
    let query: [String: AnyObject] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrAccount as String: keyName as AnyObject,
        kSecReturnData as String: kCFBooleanTrue,
        kSecMatchLimit as String: kSecMatchLimitOne
    ]
    
    var dataTypeRef: AnyObject?
    let status = SecItemCopyMatching(query as CFDictionary, &dataTypeRef)
    
    if status == errSecSuccess {
        if let data = dataTypeRef as? Data {
            return String(data: data, encoding: .utf8)
        }
    }
    return nil
}

func deleteAPIKey(for keyName: String) {
    let query: [String: AnyObject] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrAccount as String: keyName as AnyObject
    ]
    
    let status = SecItemDelete(query as CFDictionary)
    if status == errSecSuccess {
        print("API key deleted successfully")
    } else {
        print("Error deleting API key: \(status)")
    }
}

