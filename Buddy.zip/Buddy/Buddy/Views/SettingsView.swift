import SwiftUI

struct SettingsView: View {
    @State private var chatGPTAPIKey: String = getAPIKey(for: "ChatGPTAPIKey") ?? ""
    @State private var dalleAPIKey: String = getAPIKey(for: "DalleAPIKey") ?? ""
    
    var body: some View {
        VStack {
            TextField("ChatGPT API Key", text: $chatGPTAPIKey)
            Button("Save ChatGPT API Key", action: {
                saveAPIKey(chatGPTAPIKey, for: "ChatGPTAPIKey")
            })
            Button("Delete ChatGPT API Key", action: {
                deleteAPIKey(for: "ChatGPTAPIKey")
                chatGPTAPIKey = ""
            })
            
            TextField("DALL-E API Key", text: $dalleAPIKey)
            Button("Save DALL-E API Key", action: {
                saveAPIKey(dalleAPIKey, for: "DalleAPIKey")
            })
            Button("Delete DALL-E API Key", action: {
                deleteAPIKey(for: "DalleAPIKey")
                dalleAPIKey = ""
            })
            
            Button("Use DALL-E API", action: useDalleAPI)
            Spacer()
        }
        .padding()
        .frame(minWidth: 300, minHeight: 200)
    }
    
    func useDalleAPI() {
        if let apiKey = getAPIKey(for: "DalleAPIKey") {
            let dalleAPI = Dalle2API(apiKey: apiKey)
            
            // Use the dalleAPI instance here, for example:
            dalleAPI.generateImage(prompt: "A beautiful landscape") { result in
                switch result {
                case .success(let image):
                    print("Generated image: \(image)")
                case .failure(let error):
                    print("Error generating image: \(error)")
                }
            }
        } else {
            print("DALL-E API key not found")
        }
    }
}
