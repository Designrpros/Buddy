
import SwiftUI

struct ChatSettingsView: View {
    var body: some View {
        VStack {
            Text("Settings")
                .font(.title)
                .padding()
            Divider()
            Text("Option 1")
            Text("Option 2")
            Text("Option 3")
            Spacer()
        }
        .frame(width: 200, height: 200)
        .background(Color.gray)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.gray, lineWidth: 1)
        )
        .padding()
    }
}



struct ChatSettingsView_Previews: PreviewProvider {
    static var previews: some View {
        ChatSettingsView()
    }
}
