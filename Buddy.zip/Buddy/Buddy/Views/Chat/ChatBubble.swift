import SwiftUI
import AppKit // Import AppKit for the macOS app

struct ChatBubble: View {
    let messengerName: String
    let message: String
    let isSentByUser: Bool
    let isCodeBlock: Bool
    
    init(messengerName: String, message: String) {
        self.messengerName = messengerName
        self.message = message
        self.isSentByUser = message.starts(with: "Me: ")
        self.isCodeBlock = message.contains("```") // Check if the message contains a code block
    }
    
    var body: some View {
        VStack(alignment: isSentByUser ? .trailing : .leading) {
            Text(messengerName)
                .font(.caption)
                .foregroundColor(.secondary)
                .padding(isSentByUser ? .trailing : .leading, 8)
            
            if isCodeBlock {
                HStack {
                    ScrollView(.vertical, showsIndicators: true) {
                        Text(message.replacingOccurrences(of: "Me: ", with: "").replacingOccurrences(of: "```", with: ""))
                            .font(.system(size: 16, design: .monospaced))
                            .foregroundColor(.white)
                    }
                    .background(Color.black)
                    .cornerRadius(12)
                    .frame(maxWidth: .infinity, maxHeight: 400, alignment: isSentByUser ? .trailing : .leading)
                    
                    Button(action: {
                        let pasteboard = NSPasteboard.general
                        pasteboard.declareTypes([.string], owner: nil)
                        pasteboard.setString(message.replacingOccurrences(of: "Me: ", with: "").replacingOccurrences(of: "```", with: ""), forType: .string)
                    }) {
                        Image(systemName: "doc.on.doc.fill")
                            .font(.system(size: 18))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 6)
                    }
                }
            } else {
                Text(message.replacingOccurrences(of: "Me: ", with: ""))
                    .padding(10)
                    .font(.system(size: 16))
                    .background(isSentByUser ? Color.blue.opacity(0.6) : Color.secondary.opacity(0.1))
                    .foregroundColor(isSentByUser ? .white : .primary)
                    .cornerRadius(12)
                    .frame(maxWidth: .infinity, alignment: isSentByUser ? .trailing : .leading)
            }
        }
    }
}







