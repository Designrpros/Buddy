import SwiftUI
import KeyboardShortcuts

struct Chat: Identifiable, Hashable {
    let id = UUID()
    var name: String
    var messages: [String]
}

struct ChatView: View {
    @Binding var chat: Chat
    @State private var newMessage: String = ""
    let gpt: GPTAPI
    let terminalBot = TerminalBot()

    @State private var showChatSettings: Bool = false
    @Binding var showChatSections: Bool
    @State private var selectedChat: Chat?

    var body: some View {
        HStack(spacing: 0) {
            VStack(spacing: 0) {
                if chat.messages.isEmpty {
                    Text("No messages yet")
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ScrollView {
                        ScrollViewReader { scrollView in
                            LazyVStack(spacing: 8) {
                                ForEach(chat.messages.indices, id: \.self) { index in
                                    ChatBubble(messengerName: chat.messages[index].starts(with: "Me: ") ? "Me" : "Buddy", message: chat.messages[index])
                                }
                            }
                            .padding()
                        }
                    }
                }
                
                HStack(spacing: 0) {
                    ZStack(alignment: .leading) {
                        if newMessage.isEmpty {
                            Text("Type your message")
                                .foregroundColor(.gray)
                                .padding(.leading, 16)
                        }
                        TextEditor(text: $newMessage)
                            .foregroundColor(.primary)
                            .background(Color.secondary.opacity(0.1))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .frame(height: 40)
                            .disableAutocorrection(true)
                            .onChange(of: newMessage, perform: verifyAndSend)
                    }
                    
                    Button(action: {
                        send()
                    }) {
                        Image(systemName: "paperplane.fill")
                            .font(.system(size: 18))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 6)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                    
                    Button(action: {
                        
                        //gpt.deleteConversationHistory()
                        //showChatSettings.toggle()
                    }) {
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 18))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 6)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                    .overlay(
                        GeometryReader { geometry in
                            Button(action: {
                                // let gptApi = GPTAPI()
                                //showChatSettings.toggle()
                                //gpt.deleteConversationHistory()
                                //gptApi.printConversationHistory()
                            }) {
                                Color.clear
                            }
                            .frame(width: geometry.size.width, height: geometry.size.height)
                        }
                    )
                    .buttonStyle(BorderlessButtonStyle())
                    .popover(isPresented: $showChatSettings, arrowEdge: .top) {
                        ChatSettingsView()
                            .frame(width: 200, height: 200)
                    }
                    
                    Button(action: {
                        selectedChat = nil
                        showChatSections.toggle()
                    }) {
                        Image(systemName: "list.bullet")
                            .font(.system(size: 18))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 6)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                }
                .padding()
                .background(Color.secondary.opacity(0.05))
            }
            
            if showChatSections {
                            ChatSectionsView(selectedChat: $selectedChat, showChatSections: $showChatSections)
                                .transition(.move(edge: .trailing))
                        }
                    }
                    .navigationTitle(chat.name)
                    .onChange(of: selectedChat) { newValue in
                        if let newValue = newValue {
                            chat = newValue
                        }
                    }
                }

    private func send() {
            if !newMessage.isEmpty {
                chat.messages.append("Me: " + newMessage)
                let history = chat.messages.map { message -> [String: String] in
                    let role = message.starts(with: "Me: ") ? "system" : "user"
                    let content = String(message.dropFirst(4))
                    return ["role": role, "content": content]
                }
                gpt.generateResponse(conversationHistory: history) { result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success(let response):
                            chat.messages.append("" + response)
                        case .failure(let error):
                            chat.messages.append("Error: \(error.localizedDescription)")
                        }
                    }
                }

                newMessage = ""
            }
        }


                private func verifyAndSend(_ value: String) {
                    if value.last == "\n" {
                        newMessage = String(value.dropLast())
                        send()
                    }
                }

            }


