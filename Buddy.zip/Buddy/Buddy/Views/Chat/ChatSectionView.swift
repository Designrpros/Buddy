import SwiftUI

class ChatManager: ObservableObject {
    static let shared = ChatManager()
    
    @Published var chatSections: [Chat] = [
        Chat(name: "Assistant", messages: ["Hi there!"]),
        Chat(name: "Entrepreneur", messages: ["Hello!"]),
        Chat(name: "Mick Fanning", messages: ["Hi!", "How are you?"])
    ]
    
    func deleteConversationHistory(for chat: Chat) {
        if let index = chatSections.firstIndex(where: { $0.name == chat.name }) {
            chatSections[index].messages.removeAll()
            print("Deleted conversation history for chat: \(chat.name)")
        }
    }
    
    // Other methods for managing chat sections and messages
}

struct ChatSectionsView: View {
    @Binding var selectedChat: Chat?
    @Binding var showChatSections: Bool
    @ObservedObject var chatManager = ChatManager.shared
    
    @State private var isEditing = false
    
    var body: some View {
        ZStack {
            Color("Background")
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                HStack {
                    Button(action: {
                        let newChat = Chat(name: "New Chat", messages: [])
                        chatManager.chatSections.append(newChat)
                    }) {
                        HStack {
                            Image(systemName: "plus")
                        }
                        .buttonStyle(PlainButtonStyle())
                    }.padding(.leading)
                    
                    Spacer()
                    
                    Text("Chat Sections")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Spacer()
                    
                    Button(action: {
                        isEditing.toggle()
                    }) {
                        Image(systemName: isEditing ? "checkmark" : "slider.horizontal.3")
                    }
                    .padding(.trailing)
                    .buttonStyle(PlainButtonStyle())
                    
                }
                .buttonStyle(PlainButtonStyle())
                .padding(.vertical, 16)
                .background(Color("Background-2"))
                .shadow(color: Color.black.opacity(0.15), radius: 2, x: 0, y: 2)
                
                List {
                    ForEach(chatManager.chatSections.indices, id: \.self) { index in
                        HStack {
                            if isEditing {
                                TextField("Chat name", text: $chatManager.chatSections[index].name)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                            } else {
                                Text(chatManager.chatSections[index].name)
                                    .font(.headline)
                            }
                            
                            Spacer()
                            
                            if !isEditing {
                                Button(action: {
                                    selectedChat = chatManager.chatSections[index]
                                    showChatSections = false
                                }) {
                                    Image(systemName: "message.circle.fill")
                                    
                                }.buttonStyle(PlainButtonStyle())
                                    .padding(.trailing, 5)
                                
                                Button(action: {
                                    chatManager.deleteConversationHistory(for: chatManager.chatSections[index])
                                }) {
                                    Image(systemName: "arrow.triangle.2.circlepath")
                                }.buttonStyle(PlainButtonStyle())
                            }
                            
                            if isEditing {
                                Button(action: {
                                    chatManager.chatSections.remove(at: index)
                                }) {
                                    Image(systemName: "trash")
                                        .foregroundColor(.red)
                                }.buttonStyle(PlainButtonStyle())
                                
                            }
                            
                        }.shadow(color: Color.black.opacity(0.15), radius: 2, x: 0, y: 2)
                        
                    }.padding(5)
                }
                .listStyle(PlainListStyle())
                
            }
        }.frame(width: 250)
    }
}

