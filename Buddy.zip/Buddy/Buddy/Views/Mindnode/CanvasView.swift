import SwiftUI

struct CanvasView: View {
    @ObservedObject var viewModel: CanvasViewModel
    @GestureState private var magnifyBy: CGFloat = 1.0
    @Binding var zoomScale: CGFloat

    var body: some View {
        ZStack {
            // Draw connections between nodes
            ForEach(viewModel.nodes) { node in
                if let parentId = node.parentId,
                   let parentNode = viewModel.nodes.first(where: { $0.id == parentId }) {

                    let lineColor = parentNode.color

                    ConnectionLine(from: parentNode.position, to: node.position, color: lineColor)
                        .stroke(lineColor, lineWidth: 2)
                }
            }


            // Render nodes
            ForEach(viewModel.nodes.indices, id: \.self) { index in
                MindMapNode(node: $viewModel.nodes[index])
                    .environmentObject(viewModel) // Add this line
                    .position(viewModel.nodes[index].position)
                    .onTapGesture {
                        viewModel.selectedNode = viewModel.nodes[index]
                    }
            }

        }
        .scaleEffect(zoomScale * magnifyBy)
        .gesture(MagnificationGesture()
                    .updating($magnifyBy, body: { (newValue, gestureState, transaction) in
                        gestureState = newValue
                    })
                    .onEnded { value in
                        zoomScale *= value
                    })
    }
}
