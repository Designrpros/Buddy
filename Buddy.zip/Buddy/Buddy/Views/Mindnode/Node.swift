import SwiftUI

struct MindMapNode: View {
    @Binding var node: Node
    @EnvironmentObject var canvasViewModel: CanvasViewModel
    @State private var isEditing = false
    @State private var draggedOffset: CGSize = .zero
    @State private var isHovering = false
    
    var body: some View {
        ZStack {
            if isEditing {
                TextField("Title", text: $node.title, onCommit: {
                    isEditing = false
                })
                .padding()
                .background(Color.clear)
                .cornerRadius(10)
            } else {
                Text(node.title)
                    .padding()
                    .background(node.color)
                    .cornerRadius(10)
                    .shadow(radius: 5)
                    .offset(draggedOffset)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                draggedOffset = value.translation
                            }
                            .onEnded { value in
                                node.position.x += value.translation.width
                                node.position.y += value.translation.height
                                draggedOffset = .zero
                            }
                    )
            }
            
            if isHovering {
                HStack(spacing: 4) {
                    Button(action: {
                        canvasViewModel.addChildNode(parentId: node.id)
                    }) {
                        Image(systemName: "plus")
                            .font(.system(size: 16))
                            .frame(width: 32, height: 32)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                    
                    Button(action: {
                        canvasViewModel.deleteSelectedNode()
                    }) {
                        Image(systemName: "trash")
                            .font(.system(size: 16))
                            .frame(width: 32, height: 32)
                            
                    }
                    .buttonStyle(BorderlessButtonStyle())
                }
                .position(x: node.position.x + 50, y: node.position.y)
            }
        }
        .onTapGesture(count: 2) {
            isEditing = true
        }
        .onHover { hovering in
            withAnimation(.easeInOut(duration: 0.2)) {
                isHovering = hovering
            }
        }
    }
}


struct MindMapNode_Previews: PreviewProvider {
    static var previews: some View {
        MindMapNode(node: .constant(Node(id: UUID(), title: "Example Node", position: CGPoint(x: 100, y: 100), parentId: nil, color: Color.red)))
            .environmentObject(CanvasViewModel())
    }
}


struct Node: Identifiable {
    let id: UUID
    var title: String
    var position: CGPoint
    let parentId: UUID?
    var color: Color
}

struct ConnectionLine: Shape {
    let from: CGPoint
    let to: CGPoint
    let color: Color
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: from)
        
        let controlPoint = CGPoint(x: (from.x + to.x) / 2, y: (from.y + to.y) / 2 - 100)
        path.addQuadCurve(to: to, control: controlPoint)
        
        return path
    }
}

