import SwiftUI

struct Mindnode: View {
    @StateObject private var canvasViewModel = CanvasViewModel()
    @State private var currentOffset: CGSize = .zero
    @State private var startOffset: CGSize = .zero
    @State private var showSidebar: Bool = false
    @State private var zoomScale: CGFloat = 1.0

    var body: some View {
        HSplitView {
            mainView
            if showSidebar {
                sidebarView
            }
        }
    }

    private var mainView: some View {
        VStack {
            ScrollView([.horizontal, .vertical], showsIndicators: false) {
                CanvasView(viewModel: canvasViewModel, zoomScale: $zoomScale) // Pass the zoomScale binding here
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .offset(currentOffset)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                currentOffset.width = startOffset.width + value.translation.width
                                currentOffset.height = startOffset.height + value.translation.height
                            }
                            .onEnded { _ in
                                startOffset = currentOffset
                            }
                    )
            }
            .border(Color.black, width: 1)

            HStack {

                Button(action: {
                    canvasViewModel.addNode()
                }) {
                    Label("Add Node", systemImage: "plus")
                }
                .padding()
                .buttonStyle(BorderlessButtonStyle())

                Button(action: {
                    if let parentId = canvasViewModel.selectedNode?.id {
                        canvasViewModel.addChildNode(parentId: parentId)
                    }
                }) {
                    Label("Add Child Node", systemImage: "plus.square")
                }
                .padding()
                .buttonStyle(BorderlessButtonStyle())

                Spacer()

                Button(action: {
                    zoomScale += 0.1
                }) {
                    Image(systemName: "plus.magnifyingglass")
                }
                .padding()
                .buttonStyle(BorderlessButtonStyle())

                Button(action: {
                    zoomScale = max(zoomScale - 0.1, 0.1)
                }) {
                    Image(systemName: "minus.magnifyingglass")
                }
                .padding()
                .buttonStyle(BorderlessButtonStyle())

                Spacer()

                Button(action: {
                    showSidebar.toggle()
                }) {
                    Image(systemName: showSidebar ? "sidebar.right" : "sidebar.right")
                }
                .padding()
                .buttonStyle(BorderlessButtonStyle())
            }
        }
    }

    private var sidebarView: some View {
        VStack(alignment: .leading) {
            Text("Sidebar")
                .font(.title)
                .padding()

            // Add your sidebar content here
            Spacer()
        }
        .frame(width: 200)
        .background(Color(.clear))
        .edgesIgnoringSafeArea(.all)
    }
}
