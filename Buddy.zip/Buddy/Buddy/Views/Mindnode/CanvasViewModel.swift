import SwiftUI

class CanvasViewModel: ObservableObject {
    @Published var nodes: [Node] = []
    @Published var selectedNode: Node?

    func addNode() {
        let newPosition = CGPoint(x: 100, y: 100)
        let newNode = Node(id: UUID(), title: "New Node", position: newPosition, parentId: nil, color: Color.red)
        nodes.append(newNode)
    }

    // Add parentId parameter here
    func addChildNode(parentId: UUID) {
        let parentPosition = nodes.first(where: { $0.id == parentId })?.position ?? CGPoint(x: 100, y: 100)
        let newPosition = CGPoint(x: parentPosition.x + 100, y: parentPosition.y)
        let newNode = Node(id: UUID(), title: "New Node", position: newPosition, parentId: parentId, color: Color.red)
        nodes.append(newNode)
    }
    
    func deleteSelectedNode() {
        if let selectedId = selectedNode?.id {
            let childrenIds = nodes.filter { $0.parentId == selectedId }.map { $0.id }
            nodes.removeAll { node in
                node.id == selectedId || childrenIds.contains(node.id)
            }
        }
    }
    
    func getSelectedNode() -> Node? {
        return nodes.first(where: { $0.id == selectedNode?.id })
    }
}
