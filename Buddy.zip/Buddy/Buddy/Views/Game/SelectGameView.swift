import SwiftUI

struct SelectGameView: View {
    // Placeholder data for game cards
    let games: [Game] = [
        Game(title: "BlokkoRocket", image: "spaceship", description: "BlokkoRocket is a fun and challenging rocket game."),
        Game(title: "Game 2", image: "game2", description: "Game 2 description."),
        Game(title: "Game 3", image: "game3", description: "Game 3 description."),
        Game(title: "Game 4", image: "game4", description: "Game 4 description."),
    ]
    
    @State private var selectedGame: Game? = nil

    var body: some View {
        if let game = selectedGame {
            switch game.title {
            case "BlokkoRocket":
                GameView()
            case "Game 2":
                GameView()
            case "Game 3":
                GameView()
            case "Game 4":
                GameView()
            default:
                Text("Game not found")
            }
        } else {
            VStack(alignment: .leading, spacing: 10) {
                Text("Pick a game")
                    .font(.largeTitle)
                    .padding()

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(games.prefix(4)) { game in
                            GameCard(game: game) {
                                // Custom action to be performed when the card is tapped
                                selectedGame = game
                                print("Card tapped: \(game.title)")
                            }
                        }
                    }
                    .padding()
                }
            }
        }
    }
}

struct GameCard: View {
    @State private var isInfoPopupPresented = false

    let game: Game
    let onCardTapped: () -> Void

    var body: some View {
        ZStack {
            VStack {
                Image(systemName: game.image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 150, height: 100)

                HStack {
                    Text(game.title)
                        .font(.title3)
                        .padding(.top, 8)

                    Spacer()

                    Button(action: {
                        isInfoPopupPresented = true
                    }) {
                        Image(systemName: "info.circle")
                            .foregroundColor(.blue)
                    }
                    .padding(.trailing, 8)
                    .buttonStyle(BorderlessButtonStyle())
                }
            }
            .background(Color.accentColor)
            .cornerRadius(8)
            .shadow(radius: 5)
            .contentShape(Rectangle())
            .onTapGesture {
                onCardTapped()
            }

            if isInfoPopupPresented {
                VStack {
                    Text(game.description)
                        .padding()

                    Button("Close") {
                        isInfoPopupPresented = false
                    }
                    .padding(.bottom)
                    .buttonStyle(BorderlessButtonStyle())
                }
                .frame(width: 250, height: 150)
                .background(Color.accentColor)
                .cornerRadius(8)
                .shadow(radius: 5)
            }
        }
    }
}

struct Game: Identifiable {
    let id = UUID()
    let title: String
    let image: String
    let description: String
}

struct pickGameView: View {
    let game: Game
    
    var body: some View {
        VStack {
            Text("Welcome to \(game.title)")
                .font(.largeTitle)
                .padding()
            Spacer()
        }
    }
}

struct SelectGameView_Previews: PreviewProvider {
    static var previews: some View {
        SelectGameView()
    }
}
