import SpriteKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    fileprivate var spaceship: SKSpriteNode!
    fileprivate var lastUpdateTime: TimeInterval = 0
    fileprivate let obstacleSpeed: CGFloat = 250
    fileprivate let spaceshipCategory: UInt32 = 0x1 << 0
    fileprivate let obstacleCategory: UInt32 = 0x1 << 1
    private var spacebarIsPressed = false
    private var score: Int = 0
    private var scoreLabel: SKLabelNode!
    private var gameStarted = false
    private var startButton: SKSpriteNode!
    fileprivate var backgroundUpdated = false

    
    
    override func didMove(to view: SKView) {
        print("didMove() called")
        setUpScene()
        
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -0.5)
        self.physicsWorld.contactDelegate = self
        
        isPaused = true // Pause the scene
        physicsWorld.speed = 0 // Pause the physics
        
        // Add spaceship
        spaceship = SKSpriteNode(imageNamed: "spaceship")
        spaceship.position = CGPoint(x: size.width * 0.1, y: size.height * 0.5)
        spaceship.size = CGSize(width: 50, height: 50)
        spaceship.physicsBody = SKPhysicsBody(texture: spaceship.texture!, size: spaceship.size)
        spaceship.physicsBody?.affectedByGravity = false
        spaceship.physicsBody?.categoryBitMask = spaceshipCategory
        spaceship.physicsBody?.contactTestBitMask = obstacleCategory
        spaceship.physicsBody?.collisionBitMask = 0
        addChild(spaceship)
    }
    
    func background() {
        // Add background
        let background = SKSpriteNode(imageNamed: "galaxy")
        background.size = self.size
        background.position = CGPoint(x: size.width / 2, y: size.height / 2)
        background.zPosition = -1
        addChild(background)
    }
    
    func setUpScene() {
        print("setUpScene() called")
        
        background()

        // Add start button
        startButton = SKSpriteNode(color: .green, size: CGSize(width: 150, height: 50))
        startButton.position = CGPoint(x: size.width / 2, y: size.height / 2)
        startButton.name = "startButton"
        let startLabel = SKLabelNode(fontNamed: "Helvetica")
        startLabel.fontSize = 20
        startLabel.fontColor = .white
        startLabel.text = "Start"
        startButton.addChild(startLabel)
        addChild(startButton)

        // Add score label
        scoreLabel = SKLabelNode(fontNamed: "Helvetica")
        scoreLabel.fontSize = 24
        scoreLabel.fontColor = .white
        scoreLabel.position = CGPoint(x: size.width * 0.9, y: size.height * 0.9)
        scoreLabel.text = "Score: \(score)"
        addChild(scoreLabel)
    }
    
    func startGame() {
        let spawnObstacleAction = SKAction.run { [weak self] in
            self?.spawnObstacle()
        }
        
        let waitAction = SKAction.wait(forDuration: 1.5)
        let sequence = SKAction.sequence([spawnObstacleAction, waitAction])
        let repeatForever = SKAction.repeatForever(sequence)
        run(repeatForever)
    }

    func spawnObstacle() {
        if (score < 5 || score > 10) {
            spawnSingleObstacle()
            background()
           
        } else {
            if !backgroundUpdated {
                updateBackground()
                backgroundUpdated = true
            }
            spawnWallObstacle()
        }
    }

    
    func spawnSingleObstacle() {
        print("spawnObstacle() called")
        let obstacle = SKSpriteNode(imageNamed: "rock")
        obstacle.name = "obstacle"
        obstacle.position.x = size.width + obstacle.size.width / 2
        obstacle.position.y = CGFloat.random(in: 0...(size.height - obstacle.size.height / 2))
        
        obstacle.size = CGSize(width: 150, height: 150)
        
        obstacle.physicsBody = SKPhysicsBody(texture: obstacle.texture!, size: obstacle.size)
        obstacle.physicsBody?.affectedByGravity = false
        obstacle.physicsBody?.categoryBitMask = obstacleCategory
        obstacle.physicsBody?.contactTestBitMask = spaceshipCategory
        obstacle.physicsBody?.collisionBitMask = 0
        
        addChild(obstacle)
        
        // Increment the score and update the score label
        score += 1
        scoreLabel.text = "Score: \(score)"
    }
    
    func spawnWallObstacle() {
        let gapHeight: CGFloat = CGFloat.random(in: 120...200)
        let gapYPosition: CGFloat = CGFloat.random(in: gapHeight / 2...(size.height - gapHeight / 2))
        
        let upperWall = createWall()
        upperWall.position.x = size.width + upperWall.size.width / 2
        upperWall.position.y = gapYPosition + gapHeight / 2 + upperWall.size.height / 2
        addChild(upperWall)
        
        let lowerWall = createWall()
        lowerWall.position.x = size.width + lowerWall.size.width / 2
        lowerWall.position.y = gapYPosition - gapHeight / 2 - lowerWall.size.height / 2
        addChild(lowerWall)

        // Increment the score and update the score label
        score += 1
        scoreLabel.text = "Score: \(score)"
    }

    func createWall() -> SKSpriteNode {
        let wall = SKSpriteNode(imageNamed: "wall 2")
        wall.name = "obstacle"
        wall.size = CGSize(width: 150, height: size.height)
        
        wall.physicsBody = SKPhysicsBody(texture: wall.texture!, size: wall.size)
        wall.physicsBody?.affectedByGravity = false
        wall.physicsBody?.categoryBitMask = obstacleCategory
        wall.physicsBody?.contactTestBitMask = spaceshipCategory
        wall.physicsBody?.collisionBitMask = 0
        
        return wall
    }
    
    func updateBackground() {
        if let currentBackground = childNode(withName: "background") as? SKSpriteNode {
            currentBackground.removeFromParent()
        }
        
        let newBackground = SKSpriteNode(imageNamed: "wall")
        newBackground.name = "background"
        newBackground.size = self.size
        newBackground.position = CGPoint(x: size.width / 2, y: size.height / 2)
        newBackground.zPosition = -1
        addChild(newBackground)
    }

    
    
    
    
    
    
    override func update(_ currentTime: TimeInterval) {
        let deltaTime = currentTime - lastUpdateTime
        lastUpdateTime = currentTime
        
        enumerateChildNodes(withName: "obstacle") { node, _ in
            if let obstacle = node as? SKSpriteNode {
                let moveDistance = CGFloat(deltaTime) * self.obstacleSpeed
                obstacle.position.x -= moveDistance
                
                if obstacle.position.x < -obstacle.size.width / 2 {
                    obstacle.removeFromParent()
                }
            }
        }
        
        if spaceship.position.y > size.height || spaceship.position.y < 0 {
            print("Spaceship went out of bounds")
            gameOver()
        }

        if spacebarIsPressed {
            spaceship.physicsBody?.affectedByGravity = false
            let spaceshipSpeed: CGFloat = 400
            spaceship.position.y += spaceshipSpeed * CGFloat(deltaTime)
        } else {
            spaceship.physicsBody?.affectedByGravity = true
        }
    }
    
    override func mouseDragged(with event: NSEvent) {
        let location = event.location(in: self)
        spaceship.position.y = location.y
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        print("Collision detected")
        let mask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        
        if mask == spaceshipCategory | obstacleCategory {
            gameOver()
        }
    }
    
    func gameOver() {
        print("Game over")
        // Stop spaceship movement
        spaceship.removeAllActions()
        spaceship.physicsBody?.isDynamic = false

        // Stop obstacle generation and movement
        self.removeAllActions()
        self.enumerateChildNodes(withName: "obstacle") { node, _ in
            node.removeAllActions()
        }
        
        // Display game over label and score
        let gameOverLabel = SKLabelNode(fontNamed: "Helvetica")
        gameOverLabel.fontSize = 40
        gameOverLabel.fontColor = .white
        gameOverLabel.position = CGPoint(x: size.width / 2, y: size.height / 2 + 50)
        gameOverLabel.text = "Game Over"
        addChild(gameOverLabel)
        
        let scoreLabel = SKLabelNode(fontNamed: "Helvetica")
        scoreLabel.fontSize = 30
        scoreLabel.fontColor = .white
        scoreLabel.position = CGPoint(x: size.width / 2, y: size.height / 2 - 20)
        scoreLabel.text = "Score: \(score)"
        addChild(scoreLabel)
        
        // Add restart button
        let restartButton = SKSpriteNode(color: .blue, size: CGSize(width: 150, height: 50))
        restartButton.position = CGPoint(x: size.width / 2 - 80, y: size.height / 2 - 100)
        restartButton.name = "restartButton" // Add a custom name for the restart button
        let restartLabel = SKLabelNode(fontNamed: "Helvetica")
        restartLabel.fontSize = 20
        restartLabel.fontColor = .white
        restartLabel.text = "Restart"
        restartButton.addChild(restartLabel)
        addChild(restartButton)
        
        restartButton.run(SKAction.sequence([
            SKAction.wait(forDuration: 0.5),
            SKAction.run {
                restartButton.alpha = 0.0
            },
            SKAction.wait(forDuration: 0.5),
            SKAction.run {
                let newScene = GameScene(size: self.size)
                newScene.scaleMode = self.scaleMode
                let transition = SKTransition.crossFade(withDuration: 0.5)
                self.view?.presentScene(newScene, transition: transition)
            }
        ]))
        
        // Add a quit button
        let quitButton = SKSpriteNode(color: .red, size: CGSize(width: 150, height: 50))
        quitButton.position = CGPoint(x: size.width / 2 + 80, y: size.height / 2 - 100)
        quitButton.name = "quitButton" // Add a custom name for the quit button
        let quitLabel = SKLabelNode(fontNamed: "Helvetica")
        quitLabel.fontSize = 20
        quitLabel.fontColor = .white
        quitLabel.text = "Quit"
        quitButton.addChild(quitLabel)
        addChild(quitButton)
        
        quitButton.run(SKAction.sequence([
            SKAction.wait(forDuration: 0.5),
            SKAction.run {
                quitButton.alpha = 0.0
            },
            SKAction.wait(forDuration: 0.5),
            SKAction.run {
                // Add your code here to quit the game or return to the main menu
            }
        ]))
    }
    
    override func mouseDown(with event: NSEvent) {
        let location = event.location(in: self)
        let nodesAtLocation = nodes(at: location)
        
        for node in nodesAtLocation {
            if node.name == "startButton" {
                node.removeFromParent()
                isPaused = false
                physicsWorld.speed = 1 // Resume the physics
                startGame() // Start the game
                return
            }
        }
    }

    
    override func keyDown(with event: NSEvent) {
        switch event.keyCode {
        case 49: // Spacebar
            spacebarIsPressed = true
        default:
            break
        }
    }
    
    override func keyUp(with event: NSEvent) {
        switch event.keyCode {
        case 49: // Spacebar
            spacebarIsPressed = false
        default:
            break
        }
    }
    
    

}

