import SwiftUI
import SpriteKit
import AppKit

struct GameView: NSViewRepresentable {
    typealias NSViewType = GameNSView
    
    func makeNSView(context: Context) -> GameNSView {
        let scene = GameScene(size: CGSize(width: 600, height: 400))
        let skView = GameNSView()
        skView.translatesAutoresizingMaskIntoConstraints = false
        skView.allowsTransparency = true
        skView.presentScene(scene)
        return skView
    }

    
    func updateNSView(_ nsView: GameNSView, context: Context) {
    }
}


class GameNSView: SKView {
    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
    }
    
    required init?(coder decoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
