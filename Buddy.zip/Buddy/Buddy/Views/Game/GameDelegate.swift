import Cocoa
import SpriteKit

class GameDelegate: NSObject, NSApplicationDelegate {
    var window: NSWindow!


    func applicationDidFinishLaunching(_ aNotification: Notification) {
        let windowFrame = NSRect(x: 0, y: 0, width: 600, height: 400)
        let windowStyle: NSWindow.StyleMask = [.titled, .closable, .miniaturizable, .resizable]
        let window = NSWindow(contentRect: windowFrame, styleMask: windowStyle, backing: .buffered, defer: false)
        window.title = "Game"

        let contentView = SKView(frame: windowFrame)
        window.contentView = contentView

        let scene = GameScene(size: contentView.frame.size)
        scene.scaleMode = .resizeFill
        contentView.presentScene(scene)
        contentView.ignoresSiblingOrder = true
        contentView.showsFPS = true
        contentView.showsNodeCount = true

        self.window = window
        window.center()
        window.makeKeyAndOrderFront(nil)
    }



    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }


}

