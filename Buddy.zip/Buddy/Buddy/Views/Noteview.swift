import SwiftUI

struct Note: Identifiable, Hashable, Codable {
    var id = UUID()
    var title: String
    var content: String
}

struct NoteDetailView: View {
    @Binding var note: Note
    var notes: [Note]
    var notesKey: String
    
    var body: some View {
        VStack {
            TextField("Title", text: $note.title)
                .font(.system(size: 24, weight: .semibold, design: .rounded))
                .padding(.horizontal)
            
            Divider()
            
            TextEditor(text: $note.content)
                .font(.system(size: 18, design: .rounded))
                .padding(.horizontal)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .onChange(of: note.content) { _ in
                    saveNotes()
                }
        }
        .navigationTitle(note.title)
        .padding(.top)
    }
    
    private func saveNotes() {
        if let encodedNotes = try? JSONEncoder().encode(notes) {
            UserDefaults.standard.set(encodedNotes, forKey: notesKey)
        }
    }
}

struct NotesView: View {
    @State private var notes = [
        Note(title: "Note 1", content: "Type in"),
    ]
    @State private var selectedNoteIndex: Int?
    @State private var isSidebarHidden = false
    
    private let notesKey = "notes"
    @Environment(\.scenePhase) var scenePhase
    
    var body: some View {
        ZStack {
            NavigationView {
                List(selection: $selectedNoteIndex) {
                    ForEach(notes) { note in
                        if let index = notes.firstIndex(of: note) {
                            NavigationLink(destination: NoteDetailView(note: $notes[index], notes: notes, notesKey: notesKey), tag: index, selection: $selectedNoteIndex) {
                                Text(note.title)
                            }
                        }
                    }
                }
                .listStyle(SidebarListStyle())
                .navigationTitle("Notes")
                
                Text("Select a note")
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            
            VStack {
                Spacer()
                
                HStack {
                    Button(action: {
                        let newNote = Note(title: "New Note", content: "")
                        notes.append(newNote)
                        selectedNoteIndex = notes.firstIndex(of: newNote)
                        saveNotes()
                    }) {
                        Image(systemName: "plus")
                            .font(.system(size: 18))
                            .padding(.trailing, 10)
                            .foregroundColor(.accentColor)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                    
                    Button(action: {
                        if let index = selectedNoteIndex {
                            notes.remove(at: index)
                            selectedNoteIndex = nil
                            saveNotes()
                        }
                    }) {
                        Image(systemName: "minus")
                            .font(.system(size: 18))
                            .foregroundColor(.red)
                    }
                    .disabled(selectedNoteIndex == nil)
                    .buttonStyle(BorderlessButtonStyle())
                    
                    Spacer()
                }
            }
            .padding()
        }
        .onAppear {
            if let savedNotes = UserDefaults.standard.data(forKey: notesKey) {
                if let decodedNotes = try? JSONDecoder().decode([Note].self, from: savedNotes) {
                    notes = decodedNotes
                }
            }
        }
        .onChange(of: scenePhase) { newPhase in
            if newPhase == .inactive {
                saveNotes()
            }
        }
    }
    
    private func saveNotes() {
        if let encodedNotes = try? JSONEncoder().encode(notes) {
            UserDefaults.standard.set(encodedNotes, forKey: notesKey)
        }
    }
}

struct NotesContentView_Previews: PreviewProvider {
    static var previews: some View {
        NotesView()
    }
}


