import SwiftUI

struct Canvas: View {
    @Binding var currentDrawing: Drawing
    @Binding var color: Color
    @Binding var lineWidth: CGFloat
    
    var body: some View {
        GeometryReader { geometry in
            Path { path in
                for drawing in currentDrawing.lines {
                    path.addLines(drawing.points)
                }
            }
            .stroke(color, lineWidth: lineWidth)
            .background(Color.white)
            .gesture(
                DragGesture(minimumDistance: 0.1)
                    .onChanged({ value in
                        let point = value.location
                        currentDrawing.addPoint(point)
                    })
            )
        }
    }
}

struct Drawing {
    var lines: [Line] = []
    
    mutating func addPoint(_ point: CGPoint) {
        if lines.isEmpty || lines.last!.isFinished {
            lines.append(Line(points: [point]))
        } else {
            lines[lines.count - 1].points.append(point)
        }
    }
    
    mutating func finishLine() {
        if !lines.isEmpty {
            lines[lines.count - 1].isFinished = true
        }
    }
    
    mutating func clear() {
        lines = []
    }
}

struct Line {
    var points: [CGPoint]
    var isFinished = false
}
