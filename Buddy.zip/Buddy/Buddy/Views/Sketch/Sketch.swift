import SwiftUI

struct Sketch: View {
    @State private var currentDrawing = Drawing()
    @State private var color = Color.black
    @State private var lineWidth: CGFloat = 3
    
    var body: some View {
        VStack {
            HStack {
                ColorPicker("Select color", selection: $color)
                    .padding()
                
                Slider(value: $lineWidth, in: 1...10, step: 1, label: {
                    Text("Line width: \(Int(lineWidth))")
                })
                
                Button(action: {
                    currentDrawing.clear()
                }) {
                    Text("Clear Canvas")
                }
                .padding()
                
                Spacer()
            }
            
            Canvas(currentDrawing: $currentDrawing, color: $color, lineWidth: $lineWidth)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .border(Color.black, width: 1)
        }
    }
}

struct Sketch_Previews: PreviewProvider {
    static var previews: some View {
        Sketch()
    }
}
