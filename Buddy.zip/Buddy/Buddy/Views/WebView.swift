import SwiftUI
import WebKit
import Combine

class WebViewViewModel: NSObject, ObservableObject {
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var currentURL: URL?
    
    private var webView: WKWebView?
    
    func setWebView(_ webView: WKWebView) {
        self.webView = webView
    }
    
    func goBack() {
        webView?.goBack()
    }
    
    func goForward() {
            webView?.goForward()
        }
    
    func load(_ url: URL) {
        let request = URLRequest(url: url)
        webView?.load(request)
    }
}

extension WebViewViewModel: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
    }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
            currentURL = webView.url
        }
}

struct WebView: NSViewRepresentable {
    @EnvironmentObject var viewModel: WebViewViewModel
    
    func makeCoordinator() -> Coordinator {
        Coordinator(viewModel)
    }

    func makeNSView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.navigationDelegate = context.coordinator
        viewModel.setWebView(webView)
        viewModel.load(URL(string: "https://www.google.com")!)
        return webView
    }

    func updateNSView(_ nsView: WKWebView, context: Context) {}
    
    class Coordinator: NSObject, WKNavigationDelegate {
        var viewModel: WebViewViewModel

        init(_ viewModel: WebViewViewModel) {
            self.viewModel = viewModel
        }
        
        func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
                    viewModel.currentURL = webView.url
        }
    }
}

struct CustomWebView: View {
    @ObservedObject private var viewModel = WebViewViewModel()
    @State private var urlString: String = "https://www.google.com"

    var body: some View {
        VStack {
            WebView()
                .environmentObject(viewModel)
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            HStack {
                TextField("Search Google or enter URL", text: $urlString, onCommit: {
                    if urlString.hasPrefix("http://") || urlString.hasPrefix("https://") {
                        if let url = URL(string: urlString) {
                            viewModel.load(url)
                        }
                    } else {
                        let query = urlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                        let searchURL = "https://www.google.com/search?q=\(query)"
                        if let url = URL(string: searchURL) {
                            viewModel.load(url)
                        }
                    }
                })
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .frame(width: 250)
                .padding(.horizontal, 8)

                Button(action: {
                    viewModel.goBack()
                }) {
                    Image(systemName: "chevron.left")
                        .resizable()
                        .frame(width: 14, height: 18)
                        .padding(6)
                }
                .buttonStyle(BorderlessButtonStyle())
                .background(viewModel.canGoBack ? Color("Accent").opacity(0.1) : Color.gray.opacity(0.1))
                .cornerRadius(6)
                .disabled(!viewModel.canGoBack)

                Button(action: {
                    viewModel.goForward()
                }) {
                    Image(systemName: "chevron.right")
                        .resizable()
                        .frame(width: 14, height: 18)
                        .padding(6)
                }
                .buttonStyle(BorderlessButtonStyle())
                .background(viewModel.canGoForward ? Color("Accent").opacity(0.1) : Color.gray.opacity(0.1))
                .cornerRadius(6)
                .disabled(!viewModel.canGoForward)

                // Rest of the buttons
            }
            .padding()
        }
    }
}



