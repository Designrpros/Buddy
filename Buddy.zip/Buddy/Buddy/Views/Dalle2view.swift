import SwiftUI
import UniformTypeIdentifiers

struct DallE2View: View {
    let dalle2 = Dalle2API(apiKey: "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")

    @State private var prompt: String = ""
    @State private var image: NSImage? = nil
    @State private var isLoading: Bool = false
    @State private var isSavePanelPresented: Bool = false
    @State private var saveButtonDisabled: Bool = true
    @State private var showImageHistory: Bool = false
    @State private var imageHistory: [NSImage] = []

    var body: some View {
        HSplitView {
            mainView
            if showImageHistory {
                imageHistoryView
            }
        }
        .navigationTitle("DALL-E")
    }

    private var mainView: some View {
        VStack(spacing: 0) {
            if image == nil {
                Text("No image generated yet")
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    Image(nsImage: image!)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding()
                }
            }

            HStack(spacing: 0) {
                ZStack(alignment: .leading) {
                    if prompt.isEmpty {
                        Text("Enter a prompt")
                            .foregroundColor(.gray)
                            .padding(.leading, 16)
                    }
                    TextEditor(text: $prompt)
                        .foregroundColor(.primary)
                        .background(Color.secondary.opacity(0.1))
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .frame(height: 40)
                        .disableAutocorrection(true)
                }

                Button(action: {
                    isLoading = true
                    generateImage(prompt: prompt) { result in
                        isLoading = false
                        switch result {
                        case .success(let generatedImage):
                            image = generatedImage
                            imageHistory.append(generatedImage)
                            saveButtonDisabled = false
                        case .failure(let error):
                            print("Error generating image: \(error)")
                            saveButtonDisabled = true
                        }
                    }
                }) {
                    Image(systemName: "arrowtriangle.right.fill")
                        .font(.system(size: 18))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 6)
                }
                .buttonStyle(BorderlessButtonStyle())
                .disabled(isLoading)

                HStack {
                    Button(action: {
                        isSavePanelPresented = true
                    }) {
                        Image(systemName: "square.and.arrow.down")
                    }
                    .disabled(saveButtonDisabled)
                    .buttonStyle(BorderlessButtonStyle())
                }
                .padding()
                .fileExporter(isPresented: $isSavePanelPresented, document: ImageFile(image: image ?? NSImage()), contentType: .png) { result in
                    // Handle save result
                }

                Button(action: {
                                showImageHistory.toggle()
                            }) {
                                Image(systemName: showImageHistory ? "list.bullet.indent" : "list.bullet")
                                    .padding()
                            }
                            .buttonStyle(BorderlessButtonStyle())
                            .disabled(imageHistory.isEmpty) // Disable the button when there are no images in the history
            }
            .padding()
            .background(Color.secondary.opacity(0.05))
        }
    }

    private var imageHistoryView: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                ForEach(imageHistory.suffix(10).indices, id: \.self) { index in
                    Button(action: {
                        image = imageHistory[index]
                        saveButtonDisabled = false
                    }) {
                        Image(nsImage: imageHistory[index])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                            .cornerRadius(5)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                }
            }
            .padding()
        }
    }

    func generateImage(prompt: String, completion: @escaping (Result<NSImage, Error>) -> Void) {
        dalle2.generateImage(prompt: prompt) { result in
            switch result {
            case .success(let image):
                completion(.success(image))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

    struct ImageFile: FileDocument {
        static var readableContentTypes: [UTType] { [.png, .jpeg] }
        static var writableContentTypes: [UTType] { [.png, .jpeg] }
        
        var image: NSImage
        
        init(image: NSImage) {
            self.image = image
        }
        
        init(configuration: ReadConfiguration) throws {
            guard let data = configuration.file.regularFileContents,
                  let image = NSImage(data: data) else {
                throw CocoaError(.fileReadCorruptFile)
            }
            self.image = image
        }
        
        func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
            guard let tiffData = image.tiffRepresentation,
                  let bitmapImage = NSBitmapImageRep(data: tiffData),
                  let data = bitmapImage.representation(using: .png, properties: [:]) else {
                throw CocoaError(.fileWriteUnknown)
            }
            return FileWrapper(regularFileWithContents: data)
        }
    }
}

struct DallE2View_Previews: PreviewProvider {
    static var previews: some View {
        DallE2View()
            .previewLayout(.fixed(width: 600, height: 400))
    }
}
