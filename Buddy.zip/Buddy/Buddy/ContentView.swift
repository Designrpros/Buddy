import SwiftUI

struct ContentView: View {
    @State private var showChatSections: Bool = false
    @State private var selectedTab = 0
    @State private var chat = Chat(name: "Sample Chat", messages: [])
    private let gpt = GPTAPI()


    var body: some View {
        HStack(spacing: 0) {

            VStack {
                Spacer().frame(height: 5)
                Button(action: { selectedTab = 0 }) {
                    Image(systemName: "message")
                        .font(.system(size: 15))
                        .foregroundColor(selectedTab == 0 ? Color.accentColor : Color.primary)
                }
                .buttonStyle(BorderlessButtonStyle())
                .padding(.init(top: 10, leading: 10, bottom: 10, trailing: 10))

                Button(action: { selectedTab = 1 }) {
                    Image(systemName: "photo")
                        .font(.system(size: 15))
                        .foregroundColor(selectedTab == 1 ? Color.accentColor : Color.primary)
                }
                .buttonStyle(BorderlessButtonStyle())
                .background(Color.clear)
                .padding(.init(top: 10, leading: 10, bottom: 10, trailing: 10))

                Button(action: { selectedTab = 2 }) {
                    Image(systemName: "magnifyingglass")
                        .buttonStyle(PlainButtonStyle())
                        .font(.system(size: 15))
                        .foregroundColor(selectedTab == 2 ? Color.accentColor : Color.primary)
                }
                .buttonStyle(BorderlessButtonStyle())
                .background(Color.clear)
                .padding(.init(top: 10, leading: 10, bottom: 10, trailing: 10))

                Button(action: { selectedTab = 3 }) {
                    Image(systemName: "pencil")
                        .buttonStyle(PlainButtonStyle())
                        .font(.system(size: 15))
                        .foregroundColor(selectedTab == 3 ? Color.accentColor : Color.primary)
                }
                .buttonStyle(BorderlessButtonStyle())
                .background(Color.clear)
                .padding(.init(top: 10, leading: 10, bottom: 10, trailing: 10))
                
                Button(action: { selectedTab = 4 }) {
                    Image(systemName: "scribble.variable")
                        .buttonStyle(PlainButtonStyle())
                        .font(.system(size: 15))
                        .foregroundColor(selectedTab == 4 ? Color.accentColor : Color.primary)
                }
                .buttonStyle(BorderlessButtonStyle())
                .background(Color.clear)
                .padding(.init(top: 10, leading: 10, bottom: 10, trailing: 10))
                
                Button(action: { selectedTab = 5 }) {
                    Image(systemName: "suit.diamond.fill")
                        .buttonStyle(PlainButtonStyle())
                        .font(.system(size: 15))
                        .foregroundColor(selectedTab == 5 ? Color.accentColor : Color.primary)
                }
                .buttonStyle(BorderlessButtonStyle())
                .background(Color.clear)
                .padding(.init(top: 10, leading: 10, bottom: 10, trailing: 10))
                
                Button(action: { selectedTab = 6 }) {
                    Image(systemName: "suit.diamond.fill")
                        .buttonStyle(PlainButtonStyle())
                        .font(.system(size: 15))
                        .foregroundColor(selectedTab == 6 ? Color.accentColor : Color.primary)
                }
                .buttonStyle(BorderlessButtonStyle())
                .background(Color.clear)
                .padding(.init(top: 10, leading: 10, bottom: 10, trailing: 10))
                
                Spacer()
                
                Button(action: { selectedTab = 7 }) {
                    Image(systemName: "person")
                        .buttonStyle(PlainButtonStyle())
                        .font(.system(size: 15))
                        .foregroundColor(selectedTab == 7 ? Color.accentColor : Color.primary)
                }
                .buttonStyle(BorderlessButtonStyle())
                .background(Color.clear)
                .padding(.init(top: 10, leading: 10, bottom: 10, trailing: 10))
            }
            .frame(width: 60)
            .background(Color(.separatorColor))
            
            switch selectedTab {
            case 0:
                ChatView(chat: $chat, gpt: gpt, showChatSections: $showChatSections)
            case 1:
                DallE2View()
            case 2:
                CustomWebView()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            case 3:
                NotesView()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                
            case 4:
                Sketch()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                
            case 5:
                Mindnode()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            case 6:
                SelectGameView()
                
            Spacer()
                
            case 7:
                SettingsView()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                
            default:
                Text("Select a view from the sidebar")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(NSColor.windowBackgroundColor))
                    .edgesIgnoringSafeArea(.all)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewLayout(.fixed(width: 600, height: 400))
    }
}
//