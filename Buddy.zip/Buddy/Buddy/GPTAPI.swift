import Foundation

class GPTAPI {
    
    let openAiApiKey = "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"
    let baseURL = "https://api.openai.com/v1/chat/completions"
    
    enum APIError: LocalizedError {
        case invalidURL
        case encodingError(error: Error)
        case noData
        case parsingError(error: Error)
        
        var errorDescription: String? {
            switch self {
            case .invalidURL:
                return "Invalid URL."
            case .encodingError(let error):
                return "Encoding error: \(error.localizedDescription)"
            case .noData:
                return "No data received."
            case .parsingError(let error):
                return "Error parsing JSON: \(error.localizedDescription)"
            }
        }
    }
    
    func generateResponse(conversationHistory: [[String: String]], completion: @escaping (Result<String, Error>) -> Void) {
        var truncatedConversationHistory = conversationHistory
        truncateConversationHistoryIfNeeded(&truncatedConversationHistory, maxTokens: 4000)
        
        // Check if truncatedConversationHistory is empty or contains an empty message
        if truncatedConversationHistory.isEmpty || truncatedConversationHistory.contains(where: { $0["content"]?.isEmpty == true }) {
            completion(.failure(APIError.parsingError(error: NSError(domain: "com.example.app", code: 100, userInfo: [NSLocalizedDescriptionKey: "Conversation history is empty or contains an empty message"]))))
            return
        }
        
        let requestData: [String : Any] = [
            "model": "gpt-3.5-turbo",
            "messages": truncatedConversationHistory,
            "max_tokens": 4000,
            "temperature": 0.5,
            "stop": ["\n"]
        ]
        
        guard let url = URL(string: baseURL) else {
            completion(.failure(APIError.invalidURL))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("Bearer \(openAiApiKey)", forHTTPHeaderField: "Authorization")
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: requestData, options: [])
        } catch {
            completion(.failure(APIError.encodingError(error: error)))
            return
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(APIError.noData))
                return
            }
            
            do {
                let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as! [String: Any]
                print("Received JSON response for generateResponse: \(jsonResponse)")
                
                
                if let errorDict = jsonResponse["error"] as? [String: Any] {
                    let errorMessage = errorDict["message"] as? String ?? "Unknown error"
                    completion(.failure(APIError.parsingError(error: NSError(domain: "com.example.app", code: 100, userInfo: [NSLocalizedDescriptionKey: errorMessage]))))
                    return
                }
                
                if let responseText = jsonResponse["choices"] as? [[String: Any]],
                   let choice = responseText.first,
                   let message = choice["message"] as? [String: Any],
                   let content = message["content"] as? String {
                    
                    let trimmedResponseText = content.trimmingCharacters(in: .whitespacesAndNewlines)
                    completion(.success(trimmedResponseText))
                    
                } else {
                    completion(.failure(APIError.parsingError(error: NSError(domain: "com.example.app", code: 100, userInfo: [NSLocalizedDescriptionKey: "Unable to parse JSON"]))))
                }
                
            } catch let error as NSError {
                completion(.failure(APIError.parsingError(error: error)))
            }
        }
        
        task.resume()
    }
    
    //Add a function to calculate the total tokens in the conversationHistory array:
    func totalTokens(in conversationHistory: [[String: String]]) -> Int {
        let tokenCounts = conversationHistory.map { $0["content"]?.count ?? 0 }
        return tokenCounts.reduce(0, +)
    }
    
    //Create a function that removes the oldest messages until the total token count is within the limit:
    func truncateConversationHistoryIfNeeded(_ conversationHistory: inout [[String: String]], maxTokens: Int) {
        while totalTokens(in: conversationHistory) > maxTokens {
            conversationHistory.removeFirst()
        }
    }
    
}
