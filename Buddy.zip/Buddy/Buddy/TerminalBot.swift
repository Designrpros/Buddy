import Foundation

class TerminalBot {
    
    func execute(command: String) -> String {
        let components = command.split(separator: " ")
        guard let commandType = components.first else {
            return "Invalid command."
        }
        
        let args = components.dropFirst().map { String($0) }
        
        switch commandType {
        case "list":
            return listFilesAndDirectories()
        case "create":
            guard args.count == 2 else {
                return "Usage: create <file/directory> <name>"
            }
            return createFileOrDirectory(type: args[0], name: args[1])
        case "delete":
            guard args.count == 1 else {
                return "Usage: delete <name>"
            }
            return deleteFileOrDirectory(name: args[0])
        case "system":
            guard args.count == 1 else {
                return "Usage: system <command>"
            }
            return runSystemCommand(command: args[0])
        case "info":
            return systemInformation()
        case "custom":
            guard args.count == 1 else {
                return "Usage: custom <command>"
            }
            return executeCustomCommand(command: args[0])
        default:
            return "Invalid command or not supported."
        }
    }
    
    private func listFilesAndDirectories() -> String {
        // Replace this with your actual implementation for listing files and directories
        return "Listing files and directories..."
    }
    
    private func createFileOrDirectory(type: String, name: String) -> String {
        // Replace this with your actual implementation for creating files and directories
        return "Created \(type) with name: \(name)"
    }
    
    private func deleteFileOrDirectory(name: String) -> String {
        // Replace this with your actual implementation for deleting files and directories
        return "Deleted file or directory with name: \(name)"
    }
    
    private func runSystemCommand(command: String) -> String {
        // Replace this with your actual implementation for running system commands
        return "Executing system command: \(command)"
    }
    
    private func systemInformation() -> String {
        // Replace this with your actual implementation for displaying system information
        return "System information..."
    }
    
    private func executeCustomCommand(command: String) -> String {
        // Replace this with your actual implementation for executing custom commands or scripts
        return "Executing custom command: \(command)"
    }
}
